<?php
class Donator{
    
}