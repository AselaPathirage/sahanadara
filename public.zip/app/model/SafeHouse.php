<?php
class SafeHouse{
    
}