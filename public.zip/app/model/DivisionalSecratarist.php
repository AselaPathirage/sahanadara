<?php
class DivisionalSecratarist extends Employee{
    use Viewer;
    
}