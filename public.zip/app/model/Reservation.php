<?php
class Reservation{
    
}