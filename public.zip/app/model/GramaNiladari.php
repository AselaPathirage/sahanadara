<?php
class GramaNiladari extends ResponsiblePerson{
    use Alerter;
}