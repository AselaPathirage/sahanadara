<a href="/<?php echo baseUrl; ?>/Admin/">go</a><br>
<a href="../Admin/">go</a>