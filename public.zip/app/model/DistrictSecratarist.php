<?php
class DistrictSecratarist extends Employee{
    
}