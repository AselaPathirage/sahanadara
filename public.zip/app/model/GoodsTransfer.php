<?php
class GoodsTransfer{
    
}