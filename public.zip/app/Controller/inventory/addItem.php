<?php
$manager = new InventoryManager();
