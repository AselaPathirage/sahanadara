<?php
class IncidentInitialReport{
    
}