<?php
//header("location:Admin/");
if(isset($_POST)){
    print_r($_POST);
}
?>
this is a<Br>
<a href="Admin">admin</a><br>
<a href="a">a</a><br>
<a href="b">b</a><br>