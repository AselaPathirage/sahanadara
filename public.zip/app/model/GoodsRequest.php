<?php
class GoodsRequest{
    
}