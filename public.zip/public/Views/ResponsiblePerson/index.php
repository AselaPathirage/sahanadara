<?php
header("location:ResponsiblePerson/SafeHouse/");