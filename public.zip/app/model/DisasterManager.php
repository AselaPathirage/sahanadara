<?php
class DisasterManager extends Noticer{
    use Viewer;
    use Alerter;
}