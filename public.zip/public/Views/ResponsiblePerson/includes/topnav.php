<nav>
    <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Responsible Person</span>
    </div>
    <!-- <div class="mid">
                <input type="text" placeholder="Search...">
                <i class='bx bx-search'></i>
            </div> -->
    <div class="mid">
        <a href="/<?php echo baseUrl; ?>/ResponsiblePerson/SafeHouse/">
            <span class="links_name">Safe House</span>
        </a>
        <a href="/<?php echo baseUrl; ?>/ResponsiblePerson/Report/SafeHouseReport">
            <span class="links_name">Report</span>
        </a>

    </div>
    <div class="rightcorner">
        <a href="#">
            <i class='bx bx-user'></i>
            <span class="links_name">Profile</span>
        </a>
        <a href="#" style="border: 2px solid rgb(194, 5, 5);">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
        </a>
    </div>
</nav>