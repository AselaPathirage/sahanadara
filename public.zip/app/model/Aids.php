<?php
class Aids{
    private $connection;

    public function __construct($con){
        $this->connection = $con;
    }  
}