<?php
require_once("public/Controller/Router.php");

$control = new Router();