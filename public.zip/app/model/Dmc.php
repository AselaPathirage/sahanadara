<?php
class Dmc  extends Employee{
    use Viewer;
}