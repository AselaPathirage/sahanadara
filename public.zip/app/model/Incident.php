<?php
class Incident{
    
}