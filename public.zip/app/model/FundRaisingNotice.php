<?php
class FundRaisingNotice extends Notice{
    
}