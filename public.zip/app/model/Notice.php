<?php
class Notice{
    private $connection;

    public function __construct($con){
        $this->connection = $con;
    } 
}