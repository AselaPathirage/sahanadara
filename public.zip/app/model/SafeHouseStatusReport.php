<?php
class SafeHouseStatusReport{
    
}