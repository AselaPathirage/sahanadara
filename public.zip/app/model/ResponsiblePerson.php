<?php
class ResponsiblePerson  extends Employee{
    
}