<?php
trait Alerter{
    
}