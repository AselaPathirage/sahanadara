<?php
header("location:InventoryManager/Inventory/");