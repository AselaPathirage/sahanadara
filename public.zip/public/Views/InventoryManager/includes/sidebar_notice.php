<div class="sidebar">
    <div class="logo-details">
        <a href="/<?php echo baseUrl; ?>">
            <img src="/<?php echo baseUrl; ?>/public/assets/img/social-care3.png" width="" height="35" alt="logo">
        </a>
        <span class="logo_name">SAHANADARA</span>
    </div>
    <ul class="nav-links">
        <li>
            <a href="/<?php echo baseUrl; ?>/InventoryManager/Notice/Search/" id="search">
                <i class='bx bx-search-alt-2' ></i>
                <span class="links_name">Search Notice</span>
            </a>
        </li>
        <li>
            <a href="/<?php echo baseUrl; ?>/InventoryManager/Notice/AddNotice/" id="add">
                <i class='bx bx-note' ></i>
                <span class="links_name">Add Notice</span>
            </a>
        </li>
    </ul>
</div>