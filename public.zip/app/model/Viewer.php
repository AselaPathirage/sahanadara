<?php
trait Viewer{
    
}