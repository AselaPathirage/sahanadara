<div class="sidebar">
    <div class="logo-details">
        <a href="/<?php echo baseUrl; ?>">
            <img src="/<?php echo baseUrl; ?>/public/assets/img/social-care3.png" width="" height="35" alt="logo">
        </a>
        <span class="logo_name">SAHANADARA</span>
    </div>
    <ul class="nav-links">
        <li>
            <a href="/<?php echo baseUrl; ?>/InventoryManager/SafeHouse/SafeHouseDetails" class="active">
                <i class='bx bx-building-house' ></i>
                <span class="links_name">Safe House Details</span>
            </a>
        </li>
    </ul>
</div>