<?php
class Inventory{
    
}