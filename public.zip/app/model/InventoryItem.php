<?php
class InventoryItem extends Item{
    
}